/* global React */
const { useState: _useStateSidebar } = React;

function Sidebar({ rooms, currentRoomId, onJoin, onSelect, onCreate, registered }) {
  const [q, setQ] = _useStateSidebar('');
  return (
    <div className="sidebar">
      <div className="sidebar-header">Комнаты</div>
      <div className="sidebar-search">
        <form onSubmit={(e) => { e.preventDefault(); if (q) onJoin(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по ID комнаты..." maxLength={10} />
          <button className="btn" type="submit" style={{ width: '100%', marginTop: 6 }}>Войти</button>
        </form>
      </div>
      <div className="sidebar-list">
        {rooms.map(r => (
          <a key={r.id} onClick={() => onSelect(r.id)}
             className={`room-item ${r.id === currentRoomId ? 'active' : ''}`}
             style={{ fontFamily: r.name === r.id ? "'JetBrains Mono', monospace" : 'inherit', fontSize: 13 }}>
            {r.name || r.id}
          </a>
        ))}
        {rooms.length === 0 && <div style={{ fontSize: 12, color: '#888', padding: '12px', textAlign: 'center' }}>Нет посещённых комнат</div>}
      </div>
      {registered && (
        <div className="sidebar-footer">
          <button className="btn btn-primary" onClick={onCreate} style={{ width: '100%' }}>Создать комнату</button>
        </div>
      )}
    </div>
  );
}

window.Sidebar = Sidebar;
