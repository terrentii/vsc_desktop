/* global React */
const { useState } = React;

function Chrome({ user, children, status }) {
  return (
    <div className="mys-app">
      <div className="menubar">
        <div className="menubar-left">
          <img src="../../assets/vsc-logo-light.png" alt="" className="menubar-logo" />
          <a href="#">МЫС Web</a>
        </div>
        <div className="menubar-right">
          {user ? (<>
            <span className="user-badge">{user}</span>
            <button className="menu-btn">Выход</button>
          </>) : (<>
            <a href="#">Вход</a><a href="#">Регистрация</a>
          </>)}
        </div>
      </div>
      <div className="app-body">{children}</div>
      <div className="statusbar">{status || 'Готово'}</div>
    </div>
  );
}

window.Chrome = Chrome;
