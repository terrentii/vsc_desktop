/* global React, ReactDOM, Chrome, Sidebar, Chat, Disclaimer, AuthForm */
const { useState } = React;

const SEED_ROOMS = [
  { id: '3819472056', name: 'Курилка #1329', founder: 'terrentii', open: true },
  { id: '8814005720', name: '', founder: 'terrentii', open: false },
  { id: '0042100420', name: 'НИИ', founder: 'someone-else', open: true },
];

const SEED_MSGS = {
  '3819472056': [
    { author: 'Anon42', text: 'Кто здесь главный?', time: 'сегодня 14:30' },
    { author: 'terrentii', text: 'Прародитель этой комнаты — я. Управление через одноимённую кнопку.', time: 'сегодня 14:31',
      replyTo: { author: 'Anon42', text: 'Кто здесь главный?' } },
    { author: 'Anon991', text: 'Хорошо, понял. А закрытые комнаты — что это?', time: 'сегодня 14:33' },
    { author: 'terrentii', text: 'В закрытую можно войти, только если ты в users.csv этой комнаты.', time: 'сегодня 14:34' },
  ],
  '8814005720': [
    { author: 'terrentii', text: 'Это закрытая комната. Сюда я никого не зову.', time: 'вчера 22:11' },
  ],
  '0042100420': [],
};

function App() {
  const [view, setView] = useState('app'); // 'app' | 'login' | 'register'
  const [user, setUser] = useState('terrentii'); // null = anon
  const [rooms, setRooms] = useState(SEED_ROOMS);
  const [currentRoomId, setCurrentRoomId] = useState('3819472056');
  const [allMessages, setAllMessages] = useState(SEED_MSGS);
  const [showDisc, setShowDisc] = useState(user === null);

  const room = rooms.find(r => r.id === currentRoomId);
  const messages = allMessages[currentRoomId] || [];
  const currentUser = user || 'Anon42';
  const isFounder = room && user && room.founder === user;

  const send = ({ text, replyTo }) => {
    const m = { author: currentUser, text, time: 'сейчас', replyTo };
    setAllMessages(prev => ({ ...prev, [currentRoomId]: [...(prev[currentRoomId] || []), m] }));
  };

  const create = () => {
    const id = Math.floor(1e9 + Math.random() * 9e9).toString();
    const newRoom = { id, name: '', founder: user, open: true };
    setRooms([...rooms, newRoom]);
    setAllMessages({ ...allMessages, [id]: [] });
    setCurrentRoomId(id);
  };

  if (view === 'login' || view === 'register') {
    return (
      <Chrome user={user} status="Готово">
        <AuthForm mode={view}
          onSubmit={({ login }) => { setUser(login); setView('app'); setShowDisc(false); }}
          onSwitch={() => setView(view === 'login' ? 'register' : 'login')} />
      </Chrome>
    );
  }

  return (
    <Chrome user={user} status={room ? `Комната ${room.id}` : 'Готово'}>
      <div className="messenger">
        <Sidebar rooms={rooms} currentRoomId={currentRoomId}
          onJoin={(id) => { if (rooms.find(r => r.id === id)) setCurrentRoomId(id); }}
          onSelect={setCurrentRoomId}
          onCreate={create}
          registered={!!user} />
        {room ? (
          <Chat room={room} messages={messages} currentUser={currentUser} onSend={send}
            onLeave={() => alert('Покинуть комнату (демо)')}
            onManage={() => alert('Открыть управление (демо)')}
            isFounder={isFounder}
            registered={!!user} />
        ) : (
          <div className="chat-panel"><div className="chat-empty">Введите ID комнаты для начала общения</div></div>
        )}
      </div>
      {showDisc && !user && <Disclaimer onClose={() => setShowDisc(false)} />}
    </Chrome>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
