# UI Kit — МЫС Web

Pixel-faithful recreation of the МЫС Web messenger (Flask templates from `terrentii/vsc_web`). Cosmetic-only React components — no real Flask, no real polling. Click-thru demo: pick a room → see chat → send a fake message.

## Components
- `Chrome.jsx` — top menubar + bottom statusbar shell
- `Sidebar.jsx` — rooms list with search + create
- `Chat.jsx` — chat panel with message bubbles, reply, attachment input
- `Disclaimer.jsx` — anonymous-warning overlay
- `AuthForm.jsx` — login/register centered card

Mounted in `index.html` as a single demo app.
