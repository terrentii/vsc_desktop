/* global React */
function Disclaimer({ onClose }) {
  return (
    <div className="disclaimer-overlay">
      <div className="disclaimer-box">
        <div className="disclaimer-title">⚠ Внимание</div>
        <div className="disclaimer-body">
          <p>Вы входите в чат как <strong>анонимный пользователь</strong>.</p>
          <p>Несмотря на отсутствие регистрации, ваши сообщения могут содержать косвенные признаки, по которым вас можно <strong>деанонимизировать</strong>: стиль письма, упоминание личных деталей, IP-адрес и другие технические метаданные.</p>
          <p>Будьте осторожны в своих высказываниях.</p>
        </div>
        <button className="btn btn-primary disclaimer-ok" onClick={onClose}>Понятно</button>
      </div>
    </div>
  );
}

function AuthForm({ mode, onSubmit, onSwitch, error }) {
  const [login, setLogin] = React.useState('');
  const [password, setPassword] = React.useState('');
  const isLogin = mode === 'login';
  return (
    <div style={{ flex: 1, overflowY: 'auto' }}>
      <div className="centered-container">
        <h2>{isLogin ? 'Вход' : 'Регистрация'}</h2>
        {error && <p className="error">{error}</p>}
        <form onSubmit={(e) => { e.preventDefault(); onSubmit({ login, password }); }}>
          <div className="form-group">
            <label htmlFor="login">Логин</label>
            <input type="text" id="login" value={login} onChange={(e) => setLogin(e.target.value)} required />
          </div>
          <div className="form-group">
            <label htmlFor="password">Пароль</label>
            <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button className="btn btn-primary" type="submit">{isLogin ? 'Войти' : 'Зарегистрироваться'}</button>
        </form>
        <p style={{ marginTop: 12, fontSize: 12, color: '#666' }}>
          {isLogin ? 'Нет аккаунта? ' : 'Уже есть аккаунт? '}
          <a href="#" onClick={(e) => { e.preventDefault(); onSwitch(); }}>{isLogin ? 'Регистрация' : 'Войти'}</a>
        </p>
      </div>
    </div>
  );
}

window.Disclaimer = Disclaimer;
window.AuthForm = AuthForm;
