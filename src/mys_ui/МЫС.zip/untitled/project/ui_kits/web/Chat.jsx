/* global React */
const { useState: _useStateChat, useRef: _useRefChat, useEffect: _useEffChat } = React;

function MessageBubble({ msg, isOwn, onReply }) {
  return (
    <div className="msg">
      <div className="msg-header">
        <span className="msg-author">{msg.author}</span>
        <span className="msg-time">{msg.time}</span>
      </div>
      <span className="msg-actions">
        {isOwn && <button className="edit-btn">Изменить</button>}
        <button className="reply-btn" onClick={() => onReply && onReply(msg)}>Ответить</button>
      </span>
      {msg.replyTo && (
        <a className="msg-reply-link" href="#">ответ на {msg.replyTo.author}: {msg.replyTo.text.slice(0, 60)}</a>
      )}
      <div className="msg-text">{msg.text}</div>
    </div>
  );
}

function Chat({ room, messages, currentUser, onSend, onLeave, onManage, isFounder, registered }) {
  const [text, setText] = _useStateChat('');
  const [reply, setReply] = _useStateChat(null);
  const [attached, setAttached] = _useStateChat(false);
  const scrollRef = _useRefChat(null);

  _useEffChat(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const submit = (e) => {
    e.preventDefault();
    if (!text.trim() && !attached) return;
    onSend({ text: text.trim(), replyTo: reply, attached });
    setText(''); setReply(null); setAttached(false);
  };

  return (
    <div className="chat-panel">
      <div className="chat-header">
        <span>{room.name || room.id}</span>
        {room.name && <span style={{ marginLeft: 8, fontSize: 11, color: '#999', fontWeight: 'normal', fontFamily: "'JetBrains Mono', monospace" }}>{room.id}</span>}
        {registered && (
          isFounder ? (
            <button className="btn" style={{ marginLeft: 12, padding: '2px 10px', fontSize: 12 }} onClick={onManage}>Управление</button>
          ) : (
            <button className="btn" style={{ marginLeft: 12, padding: '2px 10px', fontSize: 12, color: '#da4453', borderColor: '#da4453' }} onClick={onLeave}>Покинуть</button>
          )
        )}
      </div>

      <div className="chat-messages" ref={scrollRef}>
        {messages.length === 0 ? (
          <p style={{ color: '#999', textAlign: 'center', marginTop: 20 }}>Сообщений пока нет.</p>
        ) : messages.map((m, i) => (
          <MessageBubble key={i} msg={m} isOwn={m.author === currentUser} onReply={(msg) => setReply(msg)} />
        ))}
      </div>

      <form onSubmit={submit}>
        {reply && (
          <div className="reply-preview" style={{ display: 'flex' }}>
            <span>Ответ на {reply.author}</span>
            <button type="button" className="reply-cancel" onClick={() => setReply(null)}>×</button>
          </div>
        )}
        {attached && (
          <div className="upload-preview" style={{ display: 'flex' }}>
            <span>📎</span>
            <span className="upload-preview-name">photo.png</span>
            <button type="button" className="upload-preview-cancel" onClick={() => setAttached(false)}>×</button>
          </div>
        )}
        <div className="chat-input">
          <button type="button" className={`attach-btn ${attached ? 'has-file' : ''}`} onClick={() => setAttached(!attached)} title="Прикрепить файл">📎</button>
          <input type="text" value={text} onChange={(e) => setText(e.target.value)} placeholder="Сообщение или файл..." autoComplete="off" />
          <button className="btn btn-primary" type="submit">Отправить</button>
        </div>
      </form>
    </div>
  );
}

window.Chat = Chat;
window.MessageBubble = MessageBubble;
