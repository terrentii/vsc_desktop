/* global React */
const { useState: _useStateShell } = React;

function DeskShell({ theme, onToggleTheme, status, peer, onOpenSettings, children }) {
  const logo = theme === 'dark' ? '../../assets/vsc-logo-dark.png' : '../../assets/vsc-logo-light.png';
  return (
    <div className={`desk ${theme}`}>
      <div className="desk-titlebar">
        <div className="desk-title">
          <img src={logo} alt="" className="desk-titlebar-logo" />
          <span className="desk-logo">МЫС</span>
          <span className="desk-subtitle">P2P · {peer || 'не подключён'}</span>
        </div>
        <div className="desk-title-actions">
          <button className="desk-tb-btn" onClick={onOpenSettings} title="Настройки">⚙</button>
          <button className="desk-tb-btn" onClick={onToggleTheme} title="Тема">{theme === 'light' ? '☾' : '☀'}</button>
        </div>
      </div>
      <div className="desk-body">{children}</div>
      <div className="desk-statusbar">
        <span className="status-dot" />
        <span>{status || 'Готово'}</span>
      </div>
    </div>
  );
}
window.DeskShell = DeskShell;
