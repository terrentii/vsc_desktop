/* global React */
const { useState: _useStateContacts } = React;

function Contacts({ contacts, currentId, onSelect, onAdd }) {
  const [showAdd, setShowAdd] = _useStateContacts(false);
  const [val, setVal] = _useStateContacts('');
  return (
    <div className="contacts">
      <div className="contacts-header">
        <span>Контакты</span>
        <button className="contacts-add-btn" onClick={() => setShowAdd(!showAdd)} title="Добавить">+</button>
      </div>
      {showAdd && (
        <div className="contacts-add-row">
          <input className="desk-input" value={val} onChange={(e) => setVal(e.target.value)}
                 placeholder="username@hostname:port" />
          <button className="desk-btn desk-btn-primary"
                  onClick={() => { if (val) { onAdd(val); setVal(''); setShowAdd(false); } }}>Добавить</button>
        </div>
      )}
      <div className="contacts-list">
        {contacts.map(c => (
          <div key={c.id} onClick={() => onSelect(c.id)}
               className={`contact-row ${c.id === currentId ? 'active' : ''}`}>
            <div className={`contact-avatar ${c.online ? 'on' : 'off'}`}>{c.id.charAt(0).toUpperCase()}</div>
            <div className="contact-meta">
              <div className="contact-name">{c.name}</div>
              <div className="contact-id">{c.id}</div>
            </div>
            {c.unread > 0 && <div className="contact-unread">{c.unread}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
window.Contacts = Contacts;
