/* global React */
const { useState: _useStateChatPane, useEffect: _useEffChatPane, useRef: _useRefChatPane } = React;

function ChatPane({ peer, messages, onSend, currentUser }) {
  const [text, setText] = _useStateChatPane('');
  const [reply, setReply] = _useStateChatPane(null);
  const scrollRef = _useRefChatPane(null);

  _useEffChatPane(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  if (!peer) {
    return <div className="chatpane chatpane-empty">Выберите контакт для начала переписки</div>;
  }

  const submit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onSend({ text: text.trim(), replyTo: reply });
    setText(''); setReply(null);
  };

  return (
    <div className="chatpane">
      <div className="chatpane-header">
        <div>
          <div className="chatpane-name">{peer.name}</div>
          <div className="chatpane-id">{peer.id} · <span className={`chatpane-state ${peer.online ? 'on' : 'off'}`}>{peer.online ? 'в сети, шифровано' : 'не в сети'}</span></div>
        </div>
        <div className="chatpane-encr" title="Fernet AES-128-CBC + HMAC">🔒 Fernet</div>
      </div>

      <div className="chatpane-messages" ref={scrollRef}>
        {messages.length === 0 && <div className="chatpane-empty-msg">Нет сообщений. Начните разговор.</div>}
        {messages.map((m, i) => {
          const own = m.from === currentUser;
          return (
            <div key={i} className={`bubble-row ${own ? 'own' : 'them'}`}>
              <div className="bubble" onDoubleClick={() => setReply(m)}>
                {m.replyTo && (
                  <div className="bubble-reply">
                    <span className="bubble-reply-name">{m.replyTo.from === currentUser ? 'вы' : peer.name}</span>
                    <span className="bubble-reply-text">{m.replyTo.text.slice(0, 70)}</span>
                  </div>
                )}
                <div className="bubble-text">{m.text}</div>
                <div className="bubble-time">{m.time}{own && <span className="bubble-check"> ✓✓</span>}</div>
              </div>
            </div>
          );
        })}
      </div>

      <form onSubmit={submit} className="chatpane-form">
        {reply && (
          <div className="chatpane-reply">
            <span>Ответ на «{reply.text.slice(0, 60)}»</span>
            <button type="button" onClick={() => setReply(null)}>×</button>
          </div>
        )}
        <div className="chatpane-input-row">
          <button type="button" className="desk-attach" title="Прикрепить файл">📎</button>
          <input type="text" value={text} onChange={(e) => setText(e.target.value)}
                 placeholder="Сообщение..." className="desk-input desk-input-pill" />
          <button type="submit" className="desk-send">Отправить</button>
        </div>
      </form>
    </div>
  );
}
window.ChatPane = ChatPane;
