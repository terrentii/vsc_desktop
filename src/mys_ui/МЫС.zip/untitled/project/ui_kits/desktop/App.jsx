/* global React, ReactDOM, DeskShell, Contacts, ChatPane, Settings, FirstRun */
const { useState } = React;

const SEED_CONTACTS = [
  { id: 'alice@dev-laptop:8765',   name: 'Алиса',     online: true,  unread: 2 },
  { id: 'bob@home-pc:8765',        name: 'Боб',       online: true,  unread: 0 },
  { id: 'cyrus@nas-router:9001',   name: 'Кир',       online: false, unread: 0 },
  { id: 'mira@thinkpad-x1:8765',   name: 'Мира',      online: true,  unread: 0 },
];

const SEED_MSGS = {
  'alice@dev-laptop:8765': [
    { from: 'alice@dev-laptop:8765', text: 'Привет! Получилось поднять P2P?', time: '14:21' },
    { from: 'me@my-pc:8765', text: 'Да, всё работает. Fernet-ключи синхронизированы.', time: '14:23' },
    { from: 'alice@dev-laptop:8765', text: 'Отлично. Логи чистые?', time: '14:24',
      replyTo: { from: 'me@my-pc:8765', text: 'Да, всё работает. Fernet-ключи синхронизированы.' } },
    { from: 'me@my-pc:8765', text: 'Чистые. Только handshake два раза проскочил — норм?', time: '14:25' },
    { from: 'alice@dev-laptop:8765', text: 'Норм, это reconnect.', time: '14:26' },
  ],
  'bob@home-pc:8765': [
    { from: 'bob@home-pc:8765', text: 'порт 8765 свободен у тебя?', time: 'вчера' },
  ],
  'cyrus@nas-router:9001': [],
  'mira@thinkpad-x1:8765': [
    { from: 'mira@thinkpad-x1:8765', text: 'Опять CSV побился?', time: 'пн' },
  ],
};

function App() {
  const [theme, setTheme] = useState('light');
  const [contacts, setContacts] = useState(SEED_CONTACTS);
  const [currentId, setCurrentId] = useState('alice@dev-laptop:8765');
  const [allMsgs, setAllMsgs] = useState(SEED_MSGS);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [wizard, setWizard] = useState(false);
  const [username, setUsername] = useState('me');
  const [port, setPort] = useState('8765');

  const me = `${username}@my-pc:${port}`;
  const peer = contacts.find(c => c.id === currentId);
  const messages = allMsgs[currentId] || [];

  const send = ({ text, replyTo }) => {
    const m = { from: me, text, time: 'сейчас', replyTo };
    setAllMsgs(prev => ({ ...prev, [currentId]: [...(prev[currentId] || []), m] }));
  };

  const addContact = (id) => {
    if (contacts.find(c => c.id === id)) return;
    setContacts([...contacts, { id, name: id.split('@')[0], online: false, unread: 0 }]);
  };

  return (
    <DeskShell theme={theme}
               onToggleTheme={() => setTheme(theme === 'light' ? 'dark' : 'light')}
               status={peer ? `Подключено: ${peer.id}` : 'Сервер запущен на порту ' + port}
               peer={me}
               onOpenSettings={() => setSettingsOpen(true)}>
      <div className="desk-main">
        <Contacts contacts={contacts} currentId={currentId}
                  onSelect={(id) => { setCurrentId(id); setContacts(cs => cs.map(c => c.id === id ? { ...c, unread: 0 } : c)); }}
                  onAdd={addContact} />
        <ChatPane peer={peer} messages={messages} onSend={send} currentUser={me} />
      </div>
      <Settings open={settingsOpen} onClose={() => setSettingsOpen(false)}
                theme={theme} onTheme={setTheme}
                username={username} onUsername={setUsername}
                port={port} onPort={setPort} />
      <FirstRun open={wizard} onDone={({ name, port: p }) => { setUsername(name); setPort(p); setWizard(false); }} />

      <div className="desk-fab" onClick={() => setWizard(true)} title="Показать wizard первого запуска">★ Wizard</div>
    </DeskShell>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
