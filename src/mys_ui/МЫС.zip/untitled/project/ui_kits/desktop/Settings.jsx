/* global React */
const { useState: _useStateSettings } = React;

function Settings({ open, onClose, theme, onTheme, username, onUsername, port, onPort }) {
  if (!open) return null;
  return (
    <div className="desk-modal-overlay" onClick={onClose}>
      <div className="desk-modal" onClick={(e) => e.stopPropagation()}>
        <div className="desk-modal-title">Настройки</div>
        <div className="desk-form-row">
          <label>Имя пользователя</label>
          <input className="desk-input" value={username} onChange={(e) => onUsername(e.target.value)} />
        </div>
        <div className="desk-form-row">
          <label>Порт WebSocket</label>
          <input className="desk-input" value={port} onChange={(e) => onPort(e.target.value)} type="number" min="1" max="65535" />
        </div>
        <div className="desk-form-row">
          <label>Тема</label>
          <div className="desk-radio-row">
            <label className={`desk-radio ${theme === 'light' ? 'sel' : ''}`}>
              <input type="radio" checked={theme === 'light'} onChange={() => onTheme('light')} /> Светлая
            </label>
            <label className={`desk-radio ${theme === 'dark' ? 'sel' : ''}`}>
              <input type="radio" checked={theme === 'dark'} onChange={() => onTheme('dark')} /> Тёмная
            </label>
          </div>
        </div>
        <div className="desk-modal-actions">
          <button className="desk-btn" onClick={onClose}>Отмена</button>
          <button className="desk-btn desk-btn-primary" onClick={onClose}>Сохранить</button>
        </div>
      </div>
    </div>
  );
}

function FirstRun({ open, onDone }) {
  const [name, setName] = React.useState('');
  const [port, setPort] = React.useState('8765');
  if (!open) return null;
  return (
    <div className="desk-modal-overlay">
      <div className="desk-modal desk-modal-wizard">
        <div className="desk-modal-title">Добро пожаловать в МЫС</div>
        <p className="desk-modal-body">Децентрализованный P2P мессенджер с шифрованием. Перед стартом — пара настроек.</p>
        <div className="desk-form-row">
          <label>Имя пользователя</label>
          <input className="desk-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="например, terrentii" />
        </div>
        <div className="desk-form-row">
          <label>Порт WebSocket</label>
          <input className="desk-input" value={port} onChange={(e) => setPort(e.target.value)} type="number" />
          <small className="desk-hint">Диапазон: 1–65535. По умолчанию 8765.</small>
        </div>
        <div className="desk-modal-actions">
          <button className="desk-btn desk-btn-primary"
                  onClick={() => { if (name && port) onDone({ name, port }); }}>Запустить</button>
        </div>
      </div>
    </div>
  );
}

window.Settings = Settings;
window.FirstRun = FirstRun;
