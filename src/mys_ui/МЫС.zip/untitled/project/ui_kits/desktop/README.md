# UI Kit — МЫС Desktop

Pixel-faithful recreation of the МЫС Desktop messenger (PyQt6 source from `terrentii/vsc_desktop`, recovered from `ThemeManager` styles in `main.py`).

Cosmetic-only React mock — no real WebSocket, no real encryption. Click-thru: pick a contact → see chat → send a fake message. Toggle light/dark.

## Components
- `DeskShell.jsx` — title bar + body + status bar
- `Contacts.jsx` — left list of `username@hostname` peers
- `ChatPane.jsx` — message bubbles with reply, send pill input
- `Settings.jsx` — modal settings dialog (theme, port, username)
- `FirstRun.jsx` — first-run wizard

Loaded in `index.html`.
