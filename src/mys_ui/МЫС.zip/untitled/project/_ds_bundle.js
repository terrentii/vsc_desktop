/* @ds-bundle: {"format":3,"namespace":"DesignSystem_019df3","components":[],"sourceHashes":{"ui_kits/desktop/App.jsx":"409c0cf868ef","ui_kits/desktop/ChatPane.jsx":"6c2d8044af3c","ui_kits/desktop/Contacts.jsx":"cb901bc61602","ui_kits/desktop/DeskShell.jsx":"84193c43817d","ui_kits/desktop/Settings.jsx":"ad506bb3aaf6","ui_kits/web/App.jsx":"e5fd262eb0f1","ui_kits/web/Auth.jsx":"b66ac98af2c9","ui_kits/web/Chat.jsx":"0553ee33edf8","ui_kits/web/Chrome.jsx":"7e772e2459ba","ui_kits/web/Sidebar.jsx":"1f30c40363f8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_019df3 = window.DesignSystem_019df3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/desktop/App.jsx
try { (() => {
/* global React, ReactDOM, DeskShell, Contacts, ChatPane, Settings, FirstRun */
const {
  useState
} = React;
const SEED_CONTACTS = [{
  id: 'alice@dev-laptop:8765',
  name: 'Алиса',
  online: true,
  unread: 2
}, {
  id: 'bob@home-pc:8765',
  name: 'Боб',
  online: true,
  unread: 0
}, {
  id: 'cyrus@nas-router:9001',
  name: 'Кир',
  online: false,
  unread: 0
}, {
  id: 'mira@thinkpad-x1:8765',
  name: 'Мира',
  online: true,
  unread: 0
}];
const SEED_MSGS = {
  'alice@dev-laptop:8765': [{
    from: 'alice@dev-laptop:8765',
    text: 'Привет! Получилось поднять P2P?',
    time: '14:21'
  }, {
    from: 'me@my-pc:8765',
    text: 'Да, всё работает. Fernet-ключи синхронизированы.',
    time: '14:23'
  }, {
    from: 'alice@dev-laptop:8765',
    text: 'Отлично. Логи чистые?',
    time: '14:24',
    replyTo: {
      from: 'me@my-pc:8765',
      text: 'Да, всё работает. Fernet-ключи синхронизированы.'
    }
  }, {
    from: 'me@my-pc:8765',
    text: 'Чистые. Только handshake два раза проскочил — норм?',
    time: '14:25'
  }, {
    from: 'alice@dev-laptop:8765',
    text: 'Норм, это reconnect.',
    time: '14:26'
  }],
  'bob@home-pc:8765': [{
    from: 'bob@home-pc:8765',
    text: 'порт 8765 свободен у тебя?',
    time: 'вчера'
  }],
  'cyrus@nas-router:9001': [],
  'mira@thinkpad-x1:8765': [{
    from: 'mira@thinkpad-x1:8765',
    text: 'Опять CSV побился?',
    time: 'пн'
  }]
};
function App() {
  const [theme, setTheme] = useState('light');
  const [contacts, setContacts] = useState(SEED_CONTACTS);
  const [currentId, setCurrentId] = useState('alice@dev-laptop:8765');
  const [allMsgs, setAllMsgs] = useState(SEED_MSGS);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [wizard, setWizard] = useState(false);
  const [username, setUsername] = useState('me');
  const [port, setPort] = useState('8765');
  const me = `${username}@my-pc:${port}`;
  const peer = contacts.find(c => c.id === currentId);
  const messages = allMsgs[currentId] || [];
  const send = ({
    text,
    replyTo
  }) => {
    const m = {
      from: me,
      text,
      time: 'сейчас',
      replyTo
    };
    setAllMsgs(prev => ({
      ...prev,
      [currentId]: [...(prev[currentId] || []), m]
    }));
  };
  const addContact = id => {
    if (contacts.find(c => c.id === id)) return;
    setContacts([...contacts, {
      id,
      name: id.split('@')[0],
      online: false,
      unread: 0
    }]);
  };
  return /*#__PURE__*/React.createElement(DeskShell, {
    theme: theme,
    onToggleTheme: () => setTheme(theme === 'light' ? 'dark' : 'light'),
    status: peer ? `Подключено: ${peer.id}` : 'Сервер запущен на порту ' + port,
    peer: me,
    onOpenSettings: () => setSettingsOpen(true)
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-main"
  }, /*#__PURE__*/React.createElement(Contacts, {
    contacts: contacts,
    currentId: currentId,
    onSelect: id => {
      setCurrentId(id);
      setContacts(cs => cs.map(c => c.id === id ? {
        ...c,
        unread: 0
      } : c));
    },
    onAdd: addContact
  }), /*#__PURE__*/React.createElement(ChatPane, {
    peer: peer,
    messages: messages,
    onSend: send,
    currentUser: me
  })), /*#__PURE__*/React.createElement(Settings, {
    open: settingsOpen,
    onClose: () => setSettingsOpen(false),
    theme: theme,
    onTheme: setTheme,
    username: username,
    onUsername: setUsername,
    port: port,
    onPort: setPort
  }), /*#__PURE__*/React.createElement(FirstRun, {
    open: wizard,
    onDone: ({
      name,
      port: p
    }) => {
      setUsername(name);
      setPort(p);
      setWizard(false);
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "desk-fab",
    onClick: () => setWizard(true),
    title: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C wizard \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430"
  }, "\u2605 Wizard"));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/desktop/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/desktop/ChatPane.jsx
try { (() => {
/* global React */
const {
  useState: _useStateChatPane,
  useEffect: _useEffChatPane,
  useRef: _useRefChatPane
} = React;
function ChatPane({
  peer,
  messages,
  onSend,
  currentUser
}) {
  const [text, setText] = _useStateChatPane('');
  const [reply, setReply] = _useStateChatPane(null);
  const scrollRef = _useRefChatPane(null);
  _useEffChatPane(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);
  if (!peer) {
    return /*#__PURE__*/React.createElement("div", {
      className: "chatpane chatpane-empty"
    }, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u043E\u043D\u0442\u0430\u043A\u0442 \u0434\u043B\u044F \u043D\u0430\u0447\u0430\u043B\u0430 \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0438");
  }
  const submit = e => {
    e.preventDefault();
    if (!text.trim()) return;
    onSend({
      text: text.trim(),
      replyTo: reply
    });
    setText('');
    setReply(null);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "chatpane"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chatpane-header"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "chatpane-name"
  }, peer.name), /*#__PURE__*/React.createElement("div", {
    className: "chatpane-id"
  }, peer.id, " \xB7 ", /*#__PURE__*/React.createElement("span", {
    className: `chatpane-state ${peer.online ? 'on' : 'off'}`
  }, peer.online ? 'в сети, шифровано' : 'не в сети'))), /*#__PURE__*/React.createElement("div", {
    className: "chatpane-encr",
    title: "Fernet AES-128-CBC + HMAC"
  }, "\uD83D\uDD12 Fernet")), /*#__PURE__*/React.createElement("div", {
    className: "chatpane-messages",
    ref: scrollRef
  }, messages.length === 0 && /*#__PURE__*/React.createElement("div", {
    className: "chatpane-empty-msg"
  }, "\u041D\u0435\u0442 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439. \u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440."), messages.map((m, i) => {
    const own = m.from === currentUser;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      className: `bubble-row ${own ? 'own' : 'them'}`
    }, /*#__PURE__*/React.createElement("div", {
      className: "bubble",
      onDoubleClick: () => setReply(m)
    }, m.replyTo && /*#__PURE__*/React.createElement("div", {
      className: "bubble-reply"
    }, /*#__PURE__*/React.createElement("span", {
      className: "bubble-reply-name"
    }, m.replyTo.from === currentUser ? 'вы' : peer.name), /*#__PURE__*/React.createElement("span", {
      className: "bubble-reply-text"
    }, m.replyTo.text.slice(0, 70))), /*#__PURE__*/React.createElement("div", {
      className: "bubble-text"
    }, m.text), /*#__PURE__*/React.createElement("div", {
      className: "bubble-time"
    }, m.time, own && /*#__PURE__*/React.createElement("span", {
      className: "bubble-check"
    }, " \u2713\u2713"))));
  })), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    className: "chatpane-form"
  }, reply && /*#__PURE__*/React.createElement("div", {
    className: "chatpane-reply"
  }, /*#__PURE__*/React.createElement("span", null, "\u041E\u0442\u0432\u0435\u0442 \u043D\u0430 \xAB", reply.text.slice(0, 60), "\xBB"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setReply(null)
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    className: "chatpane-input-row"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "desk-attach",
    title: "\u041F\u0440\u0438\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0444\u0430\u0439\u043B"
  }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: text,
    onChange: e => setText(e.target.value),
    placeholder: "\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435...",
    className: "desk-input desk-input-pill"
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "desk-send"
  }, "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C"))));
}
window.ChatPane = ChatPane;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/desktop/ChatPane.jsx", error: String((e && e.message) || e) }); }

// ui_kits/desktop/Contacts.jsx
try { (() => {
/* global React */
const {
  useState: _useStateContacts
} = React;
function Contacts({
  contacts,
  currentId,
  onSelect,
  onAdd
}) {
  const [showAdd, setShowAdd] = _useStateContacts(false);
  const [val, setVal] = _useStateContacts('');
  return /*#__PURE__*/React.createElement("div", {
    className: "contacts"
  }, /*#__PURE__*/React.createElement("div", {
    className: "contacts-header"
  }, /*#__PURE__*/React.createElement("span", null, "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B"), /*#__PURE__*/React.createElement("button", {
    className: "contacts-add-btn",
    onClick: () => setShowAdd(!showAdd),
    title: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C"
  }, "+")), showAdd && /*#__PURE__*/React.createElement("div", {
    className: "contacts-add-row"
  }, /*#__PURE__*/React.createElement("input", {
    className: "desk-input",
    value: val,
    onChange: e => setVal(e.target.value),
    placeholder: "username@hostname:port"
  }), /*#__PURE__*/React.createElement("button", {
    className: "desk-btn desk-btn-primary",
    onClick: () => {
      if (val) {
        onAdd(val);
        setVal('');
        setShowAdd(false);
      }
    }
  }, "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C")), /*#__PURE__*/React.createElement("div", {
    className: "contacts-list"
  }, contacts.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => onSelect(c.id),
    className: `contact-row ${c.id === currentId ? 'active' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: `contact-avatar ${c.online ? 'on' : 'off'}`
  }, c.id.charAt(0).toUpperCase()), /*#__PURE__*/React.createElement("div", {
    className: "contact-meta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "contact-name"
  }, c.name), /*#__PURE__*/React.createElement("div", {
    className: "contact-id"
  }, c.id)), c.unread > 0 && /*#__PURE__*/React.createElement("div", {
    className: "contact-unread"
  }, c.unread)))));
}
window.Contacts = Contacts;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/desktop/Contacts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/desktop/DeskShell.jsx
try { (() => {
/* global React */
const {
  useState: _useStateShell
} = React;
function DeskShell({
  theme,
  onToggleTheme,
  status,
  peer,
  onOpenSettings,
  children
}) {
  const logo = theme === 'dark' ? '../../assets/vsc-logo-dark.png' : '../../assets/vsc-logo-light.png';
  return /*#__PURE__*/React.createElement("div", {
    className: `desk ${theme}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-titlebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-title"
  }, /*#__PURE__*/React.createElement("img", {
    src: logo,
    alt: "",
    className: "desk-titlebar-logo"
  }), /*#__PURE__*/React.createElement("span", {
    className: "desk-logo"
  }, "\u041C\u042B\u0421"), /*#__PURE__*/React.createElement("span", {
    className: "desk-subtitle"
  }, "P2P \xB7 ", peer || 'не подключён')), /*#__PURE__*/React.createElement("div", {
    className: "desk-title-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "desk-tb-btn",
    onClick: onOpenSettings,
    title: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438"
  }, "\u2699"), /*#__PURE__*/React.createElement("button", {
    className: "desk-tb-btn",
    onClick: onToggleTheme,
    title: "\u0422\u0435\u043C\u0430"
  }, theme === 'light' ? '☾' : '☀'))), /*#__PURE__*/React.createElement("div", {
    className: "desk-body"
  }, children), /*#__PURE__*/React.createElement("div", {
    className: "desk-statusbar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "status-dot"
  }), /*#__PURE__*/React.createElement("span", null, status || 'Готово')));
}
window.DeskShell = DeskShell;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/desktop/DeskShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/desktop/Settings.jsx
try { (() => {
/* global React */
const {
  useState: _useStateSettings
} = React;
function Settings({
  open,
  onClose,
  theme,
  onTheme,
  username,
  onUsername,
  port,
  onPort
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-overlay",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-modal",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-title"
  }, "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438"), /*#__PURE__*/React.createElement("div", {
    className: "desk-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "\u0418\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F"), /*#__PURE__*/React.createElement("input", {
    className: "desk-input",
    value: username,
    onChange: e => onUsername(e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    className: "desk-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "\u041F\u043E\u0440\u0442 WebSocket"), /*#__PURE__*/React.createElement("input", {
    className: "desk-input",
    value: port,
    onChange: e => onPort(e.target.value),
    type: "number",
    min: "1",
    max: "65535"
  })), /*#__PURE__*/React.createElement("div", {
    className: "desk-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "\u0422\u0435\u043C\u0430"), /*#__PURE__*/React.createElement("div", {
    className: "desk-radio-row"
  }, /*#__PURE__*/React.createElement("label", {
    className: `desk-radio ${theme === 'light' ? 'sel' : ''}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    checked: theme === 'light',
    onChange: () => onTheme('light')
  }), " \u0421\u0432\u0435\u0442\u043B\u0430\u044F"), /*#__PURE__*/React.createElement("label", {
    className: `desk-radio ${theme === 'dark' ? 'sel' : ''}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    checked: theme === 'dark',
    onChange: () => onTheme('dark')
  }), " \u0422\u0451\u043C\u043D\u0430\u044F"))), /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "desk-btn",
    onClick: onClose
  }, "\u041E\u0442\u043C\u0435\u043D\u0430"), /*#__PURE__*/React.createElement("button", {
    className: "desk-btn desk-btn-primary",
    onClick: onClose
  }, "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C"))));
}
function FirstRun({
  open,
  onDone
}) {
  const [name, setName] = React.useState('');
  const [port, setPort] = React.useState('8765');
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-overlay"
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-modal desk-modal-wizard"
  }, /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-title"
  }, "\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 \u041C\u042B\u0421"), /*#__PURE__*/React.createElement("p", {
    className: "desk-modal-body"
  }, "\u0414\u0435\u0446\u0435\u043D\u0442\u0440\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0439 P2P \u043C\u0435\u0441\u0441\u0435\u043D\u0434\u0436\u0435\u0440 \u0441 \u0448\u0438\u0444\u0440\u043E\u0432\u0430\u043D\u0438\u0435\u043C. \u041F\u0435\u0440\u0435\u0434 \u0441\u0442\u0430\u0440\u0442\u043E\u043C \u2014 \u043F\u0430\u0440\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043A."), /*#__PURE__*/React.createElement("div", {
    className: "desk-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "\u0418\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F"), /*#__PURE__*/React.createElement("input", {
    className: "desk-input",
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, terrentii"
  })), /*#__PURE__*/React.createElement("div", {
    className: "desk-form-row"
  }, /*#__PURE__*/React.createElement("label", null, "\u041F\u043E\u0440\u0442 WebSocket"), /*#__PURE__*/React.createElement("input", {
    className: "desk-input",
    value: port,
    onChange: e => setPort(e.target.value),
    type: "number"
  }), /*#__PURE__*/React.createElement("small", {
    className: "desk-hint"
  }, "\u0414\u0438\u0430\u043F\u0430\u0437\u043E\u043D: 1\u201365535. \u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E 8765.")), /*#__PURE__*/React.createElement("div", {
    className: "desk-modal-actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "desk-btn desk-btn-primary",
    onClick: () => {
      if (name && port) onDone({
        name,
        port
      });
    }
  }, "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C"))));
}
window.Settings = Settings;
window.FirstRun = FirstRun;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/desktop/Settings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/App.jsx
try { (() => {
/* global React, ReactDOM, Chrome, Sidebar, Chat, Disclaimer, AuthForm */
const {
  useState
} = React;
const SEED_ROOMS = [{
  id: '3819472056',
  name: 'Курилка #1329',
  founder: 'terrentii',
  open: true
}, {
  id: '8814005720',
  name: '',
  founder: 'terrentii',
  open: false
}, {
  id: '0042100420',
  name: 'НИИ',
  founder: 'someone-else',
  open: true
}];
const SEED_MSGS = {
  '3819472056': [{
    author: 'Anon42',
    text: 'Кто здесь главный?',
    time: 'сегодня 14:30'
  }, {
    author: 'terrentii',
    text: 'Прародитель этой комнаты — я. Управление через одноимённую кнопку.',
    time: 'сегодня 14:31',
    replyTo: {
      author: 'Anon42',
      text: 'Кто здесь главный?'
    }
  }, {
    author: 'Anon991',
    text: 'Хорошо, понял. А закрытые комнаты — что это?',
    time: 'сегодня 14:33'
  }, {
    author: 'terrentii',
    text: 'В закрытую можно войти, только если ты в users.csv этой комнаты.',
    time: 'сегодня 14:34'
  }],
  '8814005720': [{
    author: 'terrentii',
    text: 'Это закрытая комната. Сюда я никого не зову.',
    time: 'вчера 22:11'
  }],
  '0042100420': []
};
function App() {
  const [view, setView] = useState('app'); // 'app' | 'login' | 'register'
  const [user, setUser] = useState('terrentii'); // null = anon
  const [rooms, setRooms] = useState(SEED_ROOMS);
  const [currentRoomId, setCurrentRoomId] = useState('3819472056');
  const [allMessages, setAllMessages] = useState(SEED_MSGS);
  const [showDisc, setShowDisc] = useState(user === null);
  const room = rooms.find(r => r.id === currentRoomId);
  const messages = allMessages[currentRoomId] || [];
  const currentUser = user || 'Anon42';
  const isFounder = room && user && room.founder === user;
  const send = ({
    text,
    replyTo
  }) => {
    const m = {
      author: currentUser,
      text,
      time: 'сейчас',
      replyTo
    };
    setAllMessages(prev => ({
      ...prev,
      [currentRoomId]: [...(prev[currentRoomId] || []), m]
    }));
  };
  const create = () => {
    const id = Math.floor(1e9 + Math.random() * 9e9).toString();
    const newRoom = {
      id,
      name: '',
      founder: user,
      open: true
    };
    setRooms([...rooms, newRoom]);
    setAllMessages({
      ...allMessages,
      [id]: []
    });
    setCurrentRoomId(id);
  };
  if (view === 'login' || view === 'register') {
    return /*#__PURE__*/React.createElement(Chrome, {
      user: user,
      status: "\u0413\u043E\u0442\u043E\u0432\u043E"
    }, /*#__PURE__*/React.createElement(AuthForm, {
      mode: view,
      onSubmit: ({
        login
      }) => {
        setUser(login);
        setView('app');
        setShowDisc(false);
      },
      onSwitch: () => setView(view === 'login' ? 'register' : 'login')
    }));
  }
  return /*#__PURE__*/React.createElement(Chrome, {
    user: user,
    status: room ? `Комната ${room.id}` : 'Готово'
  }, /*#__PURE__*/React.createElement("div", {
    className: "messenger"
  }, /*#__PURE__*/React.createElement(Sidebar, {
    rooms: rooms,
    currentRoomId: currentRoomId,
    onJoin: id => {
      if (rooms.find(r => r.id === id)) setCurrentRoomId(id);
    },
    onSelect: setCurrentRoomId,
    onCreate: create,
    registered: !!user
  }), room ? /*#__PURE__*/React.createElement(Chat, {
    room: room,
    messages: messages,
    currentUser: currentUser,
    onSend: send,
    onLeave: () => alert('Покинуть комнату (демо)'),
    onManage: () => alert('Открыть управление (демо)'),
    isFounder: isFounder,
    registered: !!user
  }) : /*#__PURE__*/React.createElement("div", {
    className: "chat-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chat-empty"
  }, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 ID \u043A\u043E\u043C\u043D\u0430\u0442\u044B \u0434\u043B\u044F \u043D\u0430\u0447\u0430\u043B\u0430 \u043E\u0431\u0449\u0435\u043D\u0438\u044F"))), showDisc && !user && /*#__PURE__*/React.createElement(Disclaimer, {
    onClose: () => setShowDisc(false)
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Auth.jsx
try { (() => {
/* global React */
function Disclaimer({
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "disclaimer-overlay"
  }, /*#__PURE__*/React.createElement("div", {
    className: "disclaimer-box"
  }, /*#__PURE__*/React.createElement("div", {
    className: "disclaimer-title"
  }, "\u26A0 \u0412\u043D\u0438\u043C\u0430\u043D\u0438\u0435"), /*#__PURE__*/React.createElement("div", {
    className: "disclaimer-body"
  }, /*#__PURE__*/React.createElement("p", null, "\u0412\u044B \u0432\u0445\u043E\u0434\u0438\u0442\u0435 \u0432 \u0447\u0430\u0442 \u043A\u0430\u043A ", /*#__PURE__*/React.createElement("strong", null, "\u0430\u043D\u043E\u043D\u0438\u043C\u043D\u044B\u0439 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C"), "."), /*#__PURE__*/React.createElement("p", null, "\u041D\u0435\u0441\u043C\u043E\u0442\u0440\u044F \u043D\u0430 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438, \u0432\u0430\u0448\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043C\u043E\u0433\u0443\u0442 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043A\u043E\u0441\u0432\u0435\u043D\u043D\u044B\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438, \u043F\u043E \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u0432\u0430\u0441 \u043C\u043E\u0436\u043D\u043E ", /*#__PURE__*/React.createElement("strong", null, "\u0434\u0435\u0430\u043D\u043E\u043D\u0438\u043C\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C"), ": \u0441\u0442\u0438\u043B\u044C \u043F\u0438\u0441\u044C\u043C\u0430, \u0443\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0435 \u043B\u0438\u0447\u043D\u044B\u0445 \u0434\u0435\u0442\u0430\u043B\u0435\u0439, IP-\u0430\u0434\u0440\u0435\u0441 \u0438 \u0434\u0440\u0443\u0433\u0438\u0435 \u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0435."), /*#__PURE__*/React.createElement("p", null, "\u0411\u0443\u0434\u044C\u0442\u0435 \u043E\u0441\u0442\u043E\u0440\u043E\u0436\u043D\u044B \u0432 \u0441\u0432\u043E\u0438\u0445 \u0432\u044B\u0441\u043A\u0430\u0437\u044B\u0432\u0430\u043D\u0438\u044F\u0445.")), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary disclaimer-ok",
    onClick: onClose
  }, "\u041F\u043E\u043D\u044F\u0442\u043D\u043E")));
}
function AuthForm({
  mode,
  onSubmit,
  onSwitch,
  error
}) {
  const [login, setLogin] = React.useState('');
  const [password, setPassword] = React.useState('');
  const isLogin = mode === 'login';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "centered-container"
  }, /*#__PURE__*/React.createElement("h2", null, isLogin ? 'Вход' : 'Регистрация'), error && /*#__PURE__*/React.createElement("p", {
    className: "error"
  }, error), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onSubmit({
        login,
        password
      });
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "login"
  }, "\u041B\u043E\u0433\u0438\u043D"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    id: "login",
    value: login,
    onChange: e => setLogin(e.target.value),
    required: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "form-group"
  }, /*#__PURE__*/React.createElement("label", {
    htmlFor: "password"
  }, "\u041F\u0430\u0440\u043E\u043B\u044C"), /*#__PURE__*/React.createElement("input", {
    type: "password",
    id: "password",
    value: password,
    onChange: e => setPassword(e.target.value),
    required: true
  })), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    type: "submit"
  }, isLogin ? 'Войти' : 'Зарегистрироваться')), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 12,
      fontSize: 12,
      color: '#666'
    }
  }, isLogin ? 'Нет аккаунта? ' : 'Уже есть аккаунт? ', /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onSwitch();
    }
  }, isLogin ? 'Регистрация' : 'Войти'))));
}
window.Disclaimer = Disclaimer;
window.AuthForm = AuthForm;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Auth.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Chat.jsx
try { (() => {
/* global React */
const {
  useState: _useStateChat,
  useRef: _useRefChat,
  useEffect: _useEffChat
} = React;
function MessageBubble({
  msg,
  isOwn,
  onReply
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "msg"
  }, /*#__PURE__*/React.createElement("div", {
    className: "msg-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "msg-author"
  }, msg.author), /*#__PURE__*/React.createElement("span", {
    className: "msg-time"
  }, msg.time)), /*#__PURE__*/React.createElement("span", {
    className: "msg-actions"
  }, isOwn && /*#__PURE__*/React.createElement("button", {
    className: "edit-btn"
  }, "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C"), /*#__PURE__*/React.createElement("button", {
    className: "reply-btn",
    onClick: () => onReply && onReply(msg)
  }, "\u041E\u0442\u0432\u0435\u0442\u0438\u0442\u044C")), msg.replyTo && /*#__PURE__*/React.createElement("a", {
    className: "msg-reply-link",
    href: "#"
  }, "\u043E\u0442\u0432\u0435\u0442 \u043D\u0430 ", msg.replyTo.author, ": ", msg.replyTo.text.slice(0, 60)), /*#__PURE__*/React.createElement("div", {
    className: "msg-text"
  }, msg.text));
}
function Chat({
  room,
  messages,
  currentUser,
  onSend,
  onLeave,
  onManage,
  isFounder,
  registered
}) {
  const [text, setText] = _useStateChat('');
  const [reply, setReply] = _useStateChat(null);
  const [attached, setAttached] = _useStateChat(false);
  const scrollRef = _useRefChat(null);
  _useEffChat(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);
  const submit = e => {
    e.preventDefault();
    if (!text.trim() && !attached) return;
    onSend({
      text: text.trim(),
      replyTo: reply,
      attached
    });
    setText('');
    setReply(null);
    setAttached(false);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "chat-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chat-header"
  }, /*#__PURE__*/React.createElement("span", null, room.name || room.id), room.name && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: 11,
      color: '#999',
      fontWeight: 'normal',
      fontFamily: "'JetBrains Mono', monospace"
    }
  }, room.id), registered && (isFounder ? /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      marginLeft: 12,
      padding: '2px 10px',
      fontSize: 12
    },
    onClick: onManage
  }, "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435") : /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      marginLeft: 12,
      padding: '2px 10px',
      fontSize: 12,
      color: '#da4453',
      borderColor: '#da4453'
    },
    onClick: onLeave
  }, "\u041F\u043E\u043A\u0438\u043D\u0443\u0442\u044C"))), /*#__PURE__*/React.createElement("div", {
    className: "chat-messages",
    ref: scrollRef
  }, messages.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      color: '#999',
      textAlign: 'center',
      marginTop: 20
    }
  }, "\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442.") : messages.map((m, i) => /*#__PURE__*/React.createElement(MessageBubble, {
    key: i,
    msg: m,
    isOwn: m.author === currentUser,
    onReply: msg => setReply(msg)
  }))), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit
  }, reply && /*#__PURE__*/React.createElement("div", {
    className: "reply-preview",
    style: {
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u041E\u0442\u0432\u0435\u0442 \u043D\u0430 ", reply.author), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "reply-cancel",
    onClick: () => setReply(null)
  }, "\xD7")), attached && /*#__PURE__*/React.createElement("div", {
    className: "upload-preview",
    style: {
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("span", {
    className: "upload-preview-name"
  }, "photo.png"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "upload-preview-cancel",
    onClick: () => setAttached(false)
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    className: "chat-input"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: `attach-btn ${attached ? 'has-file' : ''}`,
    onClick: () => setAttached(!attached),
    title: "\u041F\u0440\u0438\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0444\u0430\u0439\u043B"
  }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: text,
    onChange: e => setText(e.target.value),
    placeholder: "\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0444\u0430\u0439\u043B...",
    autoComplete: "off"
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    type: "submit"
  }, "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C"))));
}
window.Chat = Chat;
window.MessageBubble = MessageBubble;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Chat.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Chrome.jsx
try { (() => {
/* global React */
const {
  useState
} = React;
function Chrome({
  user,
  children,
  status
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "mys-app"
  }, /*#__PURE__*/React.createElement("div", {
    className: "menubar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "menubar-left"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/vsc-logo-light.png",
    alt: "",
    className: "menubar-logo"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u041C\u042B\u0421 Web")), /*#__PURE__*/React.createElement("div", {
    className: "menubar-right"
  }, user ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "user-badge"
  }, user), /*#__PURE__*/React.createElement("button", {
    className: "menu-btn"
  }, "\u0412\u044B\u0445\u043E\u0434")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u0412\u0445\u043E\u0434"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F")))), /*#__PURE__*/React.createElement("div", {
    className: "app-body"
  }, children), /*#__PURE__*/React.createElement("div", {
    className: "statusbar"
  }, status || 'Готово'));
}
window.Chrome = Chrome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Sidebar.jsx
try { (() => {
/* global React */
const {
  useState: _useStateSidebar
} = React;
function Sidebar({
  rooms,
  currentRoomId,
  onJoin,
  onSelect,
  onCreate,
  registered
}) {
  const [q, setQ] = _useStateSidebar('');
  return /*#__PURE__*/React.createElement("div", {
    className: "sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sidebar-header"
  }, "\u041A\u043E\u043C\u043D\u0430\u0442\u044B"), /*#__PURE__*/React.createElement("div", {
    className: "sidebar-search"
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      if (q) onJoin(q);
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "\u041F\u043E\u0438\u0441\u043A \u043F\u043E ID \u043A\u043E\u043C\u043D\u0430\u0442\u044B...",
    maxLength: 10
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn",
    type: "submit",
    style: {
      width: '100%',
      marginTop: 6
    }
  }, "\u0412\u043E\u0439\u0442\u0438"))), /*#__PURE__*/React.createElement("div", {
    className: "sidebar-list"
  }, rooms.map(r => /*#__PURE__*/React.createElement("a", {
    key: r.id,
    onClick: () => onSelect(r.id),
    className: `room-item ${r.id === currentRoomId ? 'active' : ''}`,
    style: {
      fontFamily: r.name === r.id ? "'JetBrains Mono', monospace" : 'inherit',
      fontSize: 13
    }
  }, r.name || r.id)), rooms.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: '#888',
      padding: '12px',
      textAlign: 'center'
    }
  }, "\u041D\u0435\u0442 \u043F\u043E\u0441\u0435\u0449\u0451\u043D\u043D\u044B\u0445 \u043A\u043E\u043C\u043D\u0430\u0442")), registered && /*#__PURE__*/React.createElement("div", {
    className: "sidebar-footer"
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: onCreate,
    style: {
      width: '100%'
    }
  }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043A\u043E\u043C\u043D\u0430\u0442\u0443")));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Sidebar.jsx", error: String((e && e.message) || e) }); }

})();
