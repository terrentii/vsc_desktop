# SKILL: Designing for МЫС

You are designing artifacts (slides, mockups, marketing pages, prototypes) for **МЫС** — an anonymous P2P/web messenger by `terrentii`. There are two products: **МЫС Web** (Flask, room-based, anonymous) and **МЫС Desktop** (PyQt6, P2P, encrypted). This skill orients you fast.

## Read first
1. **`README.md`** — product context, content rules, visual foundations, iconography, caveats.
2. **`colors_and_type.css`** — single source of truth for all tokens. Always `<link>` it.
3. **`ui_kits/web/`** and **`ui_kits/desktop/`** — pixel-faithful React mocks of the actual products. Copy components from here when prototyping flows; do not redraw chrome/bubbles/inputs from scratch.

## Five rules you cannot break

1. **Russian only.** All UI copy in Russian. Use «вы» (lowercase). No English fallbacks.
2. **Lead with `--mys-blue` (`#0040ff`).** `--accent-web` (`#3daee9`) and `--accent-desk` (`#007acc`) only when literally recreating the Web or Desktop product respectively.
3. **No gradients in product UI.** Hero/marketing panels may use `--mys-blue → --mys-blue-deep` and *only* that gradient.
4. **No invented SVG illustrations, no decorative emoji.** Functional unicode (`📎 ⚠ ☰ ×`) is the iconography. For replacement icons use Lucide via CDN.
5. **Mono for technical strings.** Room IDs (10-digit), `username@hostname`, ports — always `var(--font-mono)`. This is non-negotiable; mono visually labels these as system objects.

## Voice
Direct, system-y, no marketing gloss. The "brutalism" lives in **honest warnings** (`<strong>деанонимизировать</strong>`) and **bold geometric forms** (the cobalt mark on near-black). Buttons are infinitive verbs: «Войти», «Отправить», «Удалить». No `→`, no `!`, no upsell.

## Component recipes

| Need | Source |
|---|---|
| Web menubar / sidebar / chat / disclaimer | `ui_kits/web/*.jsx` |
| Desktop title bar / contacts / bubbles / settings modal | `ui_kits/desktop/*.jsx` |
| Pill button (web) | `padding: 8px 18px; border-radius: 999px; border: 1.5px solid` |
| Standard button (desktop) | `padding: 8px 16px; border-radius: 8px;` |
| Message bubble (desktop) | `border-radius: 15px` with one corner cut to `5px` on the sender side |
| Active room/contact highlight | bg `var(--mys-accent)` + white text + colored shadow `rgba(61,174,233,0.3)` |
| Focus ring | `border: 1.5px solid #3daee9; box-shadow: 0 0 0 3px rgba(61,174,233,0.15);` |

## Typography stack (substitution)
- **Display:** Museo Cyrl — delivered, loaded from `fonts/` via `@font-face`. Use `var(--font-display)` for headlines and logo-blocks. Weights map 400/500→Museo 500, 600/700/900→Museo 900.
- **UI:** `'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif` (web) or `Inter` (modern outputs).
- **Mono:** `'JetBrains Mono', 'SF Mono', Consolas, monospace`.

All three are loaded by `colors_and_type.css`. Use the `--font-display`, `--font-system`, `--font-mono` variables.

## Layout DNA — копировать без вопросов
- **Fixed chrome:** menubar (32–38px) + statusbar (22–24px) always pinned; content scrolls between. This is THE silhouette of the product.
- **Sidebar:** 270–280px, fixed. Mobile only → drawer.
- **Forms centered:** `max-width: 400–500px; margin: 60px auto; padding: 28px 32px;`

## When asked for a slide deck
Use `deck_stage.js`. Slide vocabulary:
- **Section header:** `--mys-ink` background, big white display type, optional logo bottom-left.
- **Title slide:** logo centered on `--mys-blue-deep`, product name in display weight 700, tagline mono 14px.
- **Content slide:** white bg, `--mys-ink` headlines, body in `var(--font-system)`, occasional 10-digit ID set in mono as visual anchor.
- **Stat / quote slide:** giant number/word, single line of context underneath. No data slop.

## When asked for marketing
- One screen = one assertion. Do not stack feature columns 3-across.
- Hero: cobalt logo on near-black. Tagline in white. CTA = mono pill with `--mys-blue` fill.
- Use real product UI (from `ui_kits/`) as supporting screenshots — never wireframe approximations.

## What NOT to make
- Sky-blue → purple gradient anything
- Bento grids
- Glassmorphism (except the disclaimer overlay)
- Emoji-headed feature cards
- Stock photography, Unsplash people, abstract 3D blobs
- Left-accent-bordered "callout" cards (the only allowed left-border is reply-quote `border-left: 3px solid #3daee9`)
- Invented icon sets — use Lucide or unicode

## Substitutions to declare aloud in your output's notes
- 🟡 **No icon set** in repo → using Lucide via CDN
- 🟡 **Desktop visuals reverse-engineered** from `main.py:ThemeManager` (private repo) — confirm with user before shipping high-fidelity desktop work
